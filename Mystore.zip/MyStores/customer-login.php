<?php
  include('include/header.php');
  include('dashboard/include/connection.php');
  
  if(isset($_SESSION['id']))
  {
    header('location:index.php');
  }
?>

    <!-- Hero Section-->
    <section class="hero hero-page gray-bg padding-small">
      <div class="container">
        <div class="row d-flex">
          <div class="col-lg-9 order-2 order-lg-1">
            <h1>Customer zone</h1>
          </div>
          <div class="col-lg-3 text-right order-1 order-lg-2">
            <ul class="breadcrumb justify-content-lg-end">
              <li class="breadcrumb-item"><a href="index-2.html">Home</a></li>
              <li class="breadcrumb-item active">Customer zone</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
    <!-- text page-->
    <section class="padding-small">
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <div class="block">
              <div class="block-header">
                <h5>Login</h5>
              </div>
              <div class="block-body"> 
                <p class="lead">Already our customer?</p>
                <p class="text-muted">Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.</p>
                <hr>
                <form action="" method="POST">
                  <div class="form-group">
                    <label for="email" class="form-label">Email</label>
                    <input id="email" name="email" type="text" class="form-control">
                  </div>
                  <div class="form-group">
                    <label for="password" class="form-label">Password</label>
                    <input id="password" name="password" type="password" class="form-control">
                  </div>
                  <div class="form-group text-center">
                    <button type="submit" name='login' class="btn btn-primary"><i class="fa fa-sign-in"></i> Log in</button>
                  </div>
                </form>
                <?php
                  if(isset($_POST['login']))
                  {
                    $email    = $_POST['email'];
                    $password = $_POST['password'];
                    
                    $check = mysqli_query($con,"select * from users where email = '$email' and password = '$password'");

                    if(mysqli_num_rows($check) == 1)
                    {
                      $fetch = mysqli_fetch_array($check);

                      session_start();
                      $_SESSION['id']         = $fetch['id'];
                      $_SESSION['name']       = $fetch['name'];
                      $_SESSION['user_type']  = $fetch['user_type'];
                      $_SESSION['email']      = $fetch['email'];
                      
                      if($fetch['user_type'] == 1)
                      {
                        header('location:dashboard/products.php');
                      }
                      else
                      {
                        header('location:index.php');
                      }               
                    }
                    else
                    {
                      echo '<p class="alert alert-danger">Invalid Email or Password</p>';
                    }
                  }
                
                ?>


              </div>
            </div>
          </div>
          <div class="col-lg-6">
            <div class="block">
              <div class="block-header">
                <h5>New account</h5>
              </div>
              <div class="block-body"> 
                <p class="lead">Not our registered customer yet?</p>
                <p>With registration with us new world of fashion, fantastic discounts and much more opens to you! The whole process will not take you more than a minute!</p>
                <p class="text-muted">If you have any questions, please feel free to <a href="contact.html">contact us</a>, our customer service center is working for you 24/7.</p>
                <hr>
                <form action="#" method="POST">
                  <div class="form-group">
                    <label for="name" class="form-label">Name</label>
                    <input id="name" type="text" class="form-control">
                  </div>
                  <div class="form-group">
                    <label for="email" class="form-label">Email</label>
                    <input id="email" type="text" class="form-control">
                  </div>
                  <div class="form-group">
                    <label for="password" class="form-label">Password</label>
                    <input id="password" type="password" class="form-control">
                  </div>
                  <div class="form-group text-center">
                    <button type="submit" name="insert" class="btn btn-primary"><i class="icon-profile"></i> Register </button>
                  </div>
                </form>
                <?php
                  if(isset($_POST['insert']))
                  {
                    $name = $_POST['name'];
                    $email = $_POST['email'];
                    $pass = $_POST['password'];

                    $sql_query = "INSERT INTO users (`name`,`email`,`password`) VALUES ('$name' , '$email' , '$pass')";
                    $query = mysqli_query($con,$sql_query);

                    if($query)
                    {
                      echo "incorrect Fill form";
                    }
                  
                  }

                ?>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
<?php
  include('include/footer.php')
?>